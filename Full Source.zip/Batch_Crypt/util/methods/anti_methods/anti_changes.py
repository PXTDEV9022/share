import random


from util.supporting.settings import Settings

checked = False


class AntiChanges:
    @staticmethod
    def first_line_echo_check() -> str:
        return "\n"

    @staticmethod
    def double_click_check() -> str:
        choices = [
            """echo %cmdcmdline% | find /i "%~f0">nul || exit /b 1\n""",
        ]

        return random.choice(choices)

    @staticmethod
    def anti_wifi() -> str:
        return 'ping -n 1 -w 700 www.google.com | find "Pinging" > nul || exit'

    @staticmethod
    def tests():
        choices = []

        if Settings.require_wifi:
            choices.append(AntiChanges.anti_wifi)

        if Settings.double_click_check and not Settings.debug:
            choices.append(AntiChanges.double_click_check)

        # return the name of the function used too
        choice = random.choice(choices)
        output = choice()
        return (output, choice.__name__)
