from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Random import get_random_bytes
import base64, marshal, string, zlib

def compress(code_bytes: bytes) -> bytes:
    
    zlib_compressed_code_bytes = zlib.compress(code_bytes)
    
    return zlib_compressed_code_bytes
def decompress(code_bytes: bytes) -> bytes:
    return zlib.decompress(code_bytes)


# Hàm RC4 đơn giản
def rc4(data, key):
    S = list(range(256))
    j = 0
    out = []
    # Khởi tạo
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    # Sinh key stream và XOR với data
    for char in data:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out.append(char ^ S[(S[i] + S[j]) % 256])
    return bytes(out)

# Hàm XOR đơn giản
def xor(data, key):
    return bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])

# Hàm mã hóa AES
def aes_encrypt(data, key):
    cipher = AES.new(key, AES.MODE_EAX)
    ciphertext, tag = cipher.encrypt_and_digest(data)
    return cipher.nonce + ciphertext  # Trả về nonce và ciphertext

# Hàm giải mã AES
def aes_decrypt(data, key):
    nonce = data[:16]
    ciphertext = data[16:]
    cipher = AES.new(key, AES.MODE_EAX, nonce=nonce)
    return cipher.decrypt(ciphertext)

# Tạo cặp khóa RSA
key = RSA.generate(2048)
private_key = key.export_key()
public_key = key.publickey().export_key()

# Mã hóa bằng RSA
def rsa_encrypt(data, public_key):
    rsa_cipher = PKCS1_OAEP.new(RSA.import_key(public_key))
    return rsa_cipher.encrypt(data)

# Giải mã bằng RSA
def rsa_decrypt(data, private_key):
    rsa_cipher = PKCS1_OAEP.new(RSA.import_key(private_key))
    return rsa_cipher.decrypt(data)

# Hàm mã hóa kết hợp
def hybrid_encrypt(data, rsa_public_key, rc4_key, xor_key, aes_key):
    # 1. Mã hóa bằng RC4
    rc4_encrypted = rc4(data, rc4_key)
    
    # 2. Mã hóa bằng XOR
    xor_encrypted = xor(rc4_encrypted, xor_key)
    
    # 3. Mã hóa bằng AES
    aes_encrypted = aes_encrypt(xor_encrypted, aes_key)
    
    # 4. Mã hóa khóa đối xứng (RC4 + XOR + AES) bằng RSA
    combined_key = rc4_key + xor_key + aes_key
    rsa_encrypted_key = rsa_encrypt(combined_key, rsa_public_key)
    
    # Kết hợp dữ liệu mã hóa
    # combined_encrypted = rsa_encrypted_key + aes_encrypted
    
    # # 5. Mã hóa thành Base85
    # base85_encoded = base64.b85encode(combined_encrypted).decode()
    combined_encrypted = rsa_encrypted_key + aes_encrypted
    compressed = compress(combined_encrypted)
    base85_encoded = base64.b85encode(compressed).decode()
    return base85_encoded

# Hàm giải mã kết hợp
def hybrid_decrypt(base85_encoded_data, rsa_private_key):
    # 1. Giải mã từ Base85
    compressed_data = base64.b85decode(base85_encoded_data)
    encrypted_data = decompress(compressed_data)
    # Tách khóa RSA và dữ liệu đã mã hóa
    rsa_encrypted_key = encrypted_data[:256]  # Độ dài RSA khóa 2048 là 256 byte
    aes_encrypted = encrypted_data[256:]
    
    # 2. Giải mã khóa đối xứng bằng RSA
    combined_key = rsa_decrypt(rsa_encrypted_key, rsa_private_key)
    rc4_key = combined_key[:16]
    xor_key = combined_key[16:32]
    aes_key = combined_key[32:48]
    
    # 3. Giải mã bằng AES
    xor_encrypted = aes_decrypt(aes_encrypted, aes_key)
    
    # 4. Giải mã bằng XOR
    rc4_encrypted = xor(xor_encrypted, xor_key)
    
    # 5. Giải mã bằng RC4
    decrypted_data = rc4(rc4_encrypted, rc4_key)
    
    return decrypted_data

# # Ví dụ sử dụng

rsa_public_key = public_key
rsa_private_key = private_key

# Tạo các khóa đối xứng ngẫu nhiên
rc4_key = get_random_bytes(16)
xor_key = get_random_bytes(16)
aes_key = get_random_bytes(16)

import sys
if len(sys.argv) < 2:
    print('Usage: python enc.py <file>') 
    sys.exit()
code = open(sys.argv[1], 'r', encoding='utf8').read()
print("Compiling source code to bytecode ...", end='\r')
data = marshal.dumps(compile(code, '<string>', 'exec'))
print("Encrypting bytecode with powerfull encrypter ... ", end='\r')
encrypted_data = hybrid_encrypt(data, rsa_public_key, rc4_key, xor_key, aes_key)
key = base64.b64encode(rsa_private_key).decode()
data = encrypted_data
enc = ''
list_function = []
import random
with open('runcode.py', 'r', encoding='utf8') as f:
    stub = f.read()
    stub = stub.replace('%encrypted_data%', encrypted_data)
    stub = stub.replace('%encrypted_key%', key)
    #open("run_obf.py", 'w', encoding='utf8').write(stub)
    enc = base64.b85encode(zlib.compress(marshal.dumps(compile(stub,'<string>','exec')))).decode()
def random_string(length) -> str:
    import random
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))
def generate_junk_function(num_of_var, direct_function = False):
    '''siis'''
    func_name = random_string(num_of_var) 
    if(direct_function):
        list_function.append(direct_function)
    code = f'''def sub_{func_name}():\n'''
    for i in range(num_of_var):
        _type = random.choice(['int', 'str'])
        code += '\t'+generate_variable(_type) + '\n'
        # code += f'\n\tvar_{random_string(4)} = "{random_string(4)}"'
    return code
def generate_variable(_type):
    if(_type == 'int'):
        junk_int = random.randint(1000000000,9999999999)
        return f'var_{random_string(random.randint(5,15))} = {junk_int}'
    
    junk_string = random_string(random.randint(7,18))
    return f'var_{random_string(random.randint(5,15))} = "{junk_string}"'
def redirect_entry_point(code, max_level = 3):
    numvar = max_level
    entry_func_name = f'sub_{random.randint(5,15)}'
    entry_func = f'''def {entry_func_name}():\n'''
    entry_func += '\t' + code +'\n'
    list_func = []
    list_func.append({'level': 1, 'func_name': entry_func_name})
    level = 2
    new_code = entry_func
    while level < max_level:
        
        _fn = f'sub_{random_string(random.randint(5,15))}'
        fnc_code = 'def '+ _fn + '():\n'
        #\n
        for i in range(numvar):
            _type = random.choice(['int', 'str'])
            fnc_code += '\t'+generate_variable(_type) + '\n'
        for func in list_func:
            if(func['level'] == (level - 1 )):
                name = func['func_name']
                fnc_code +=  '\t' + f'{name}()' +'\n'
                fnc_code +=  '\t' + f'#{level}' +'\n'
        list_func.append({'level': level, 'func_name': _fn})
        level += 1
        new_code += fnc_code
    if(level == max_level):
        name = list_func[-1]['func_name']
        new_code += f'{name}()'    
    return new_code

def generate_junk(num):
    code = ''''''
    for i in range(num):
        code+= generate_junk_function(num)
    return code
ruu =  f'''{generate_junk(random.randint(15,35))}\nexec(__import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b85decode("%encrypted_code%"))))'''

ruu = ruu.replace('%encrypted_code%', enc)  
ruu += '\n'
ruu += generate_junk(random.randint(15,35))
open("final_obf.py",'w', encoding='utf8').write(ruu) 
print("Done !", end='\r')
print()
